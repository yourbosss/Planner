package com.example.planner

import androidx.lifecycle.LiveData
import androidx.room.Query

class TaskRepository(private val taskDao: TaskDao) {

    val allTasks: LiveData<List<Task>> = taskDao.getAllTasks()

    suspend fun insert(task: Task) {
        taskDao.insert(task)
    }

    suspend fun update(task: Task) {
        taskDao.update(task)
    }

    suspend fun delete(task: Task) {
        taskDao.delete(task)
    }

    fun getTasksById(): List<Task?>?{
        return taskDao.getTasksById()
    }

    fun getTasksWhereCategory(category: String): List<Task?>? {
        return taskDao.getTasksWhereCategory(category)
    }

    fun getTasksByDeadline1(): List<Task?>?{
        return taskDao.getTasksByDeadline1()
    }

    fun getTasksByDeadline0(): List<Task?>?{
        return taskDao.getTasksByDeadline0()
    }

    fun getTasksByPriority1(): List<Task?>?{
        return taskDao.getTasksByPriority1()
    }

    fun getTasksByPriority0(): List<Task?>?{
        return taskDao.getTasksByPriority0()
    }

    fun getTasksWhereStatus(status: Boolean): List<Task?>?{
        return taskDao.getTasksWhereStatus(status)
    }

}
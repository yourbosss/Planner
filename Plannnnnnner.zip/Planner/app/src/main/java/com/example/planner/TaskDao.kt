package com.example.planner

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface TaskDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(task :Task)

    @Update
    suspend fun update(task: Task)

    @Delete
    suspend fun delete(task: Task)

    @Query("Select * from tasksTable order by id ASC")
    fun getAllTasks(): LiveData<List<Task>>

    @Query("SELECT * FROM tasksTable ORDER BY id ASC")
    fun getTasksById(): List<Task?>?

    @Query("SELECT * FROM tasksTable ORDER BY deadline ASC")
    fun getTasksByDeadline1(): List<Task?>?

    @Query("SELECT * FROM tasksTable ORDER BY deadline DESC")
    fun getTasksByDeadline0(): List<Task?>?

    @Query("SELECT * FROM tasksTable ORDER BY priority ASC")
    fun getTasksByPriority1(): List<Task?>?

    @Query("SELECT * FROM tasksTable ORDER BY priority DESC")
    fun getTasksByPriority0(): List<Task?>?

    @Query("SELECT * FROM tasksTable WHERE category = :category")
    fun getTasksWhereCategory(category: String?): List<Task?>?

    @Query("SELECT * FROM tasksTable WHERE done = :status")
    fun getTasksWhereStatus(status: Boolean): List<Task?>?


}
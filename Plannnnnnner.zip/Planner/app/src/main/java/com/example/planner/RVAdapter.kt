package com.example.planner

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RVAdapter(
    private val context: Context,
    private val taskClickDeleteInterface: TaskClickDeleteInterface,
    private val taskClickInterface: TaskClickInterface,
    private val taskStatusChangeInterface: TaskStatusChangeInterface
) : RecyclerView.Adapter<RVAdapter.TaskViewHolder>() {

    private val allTasks = ArrayList<Task>()

    interface TaskClickDeleteInterface {
        fun onDeleteIconClick(task: Task)
    }

    interface TaskClickInterface {
        fun onTaskClick(task: Task)
    }

    interface TaskStatusChangeInterface {
        fun onTaskStatusChange(task: Task, isChecked: Boolean)
    }

    // Определение ViewHolder, который будет использоваться для всех типов представлений
    class TaskViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val taskTitleTextView: TextView = view.findViewById(R.id.title)
        val taskCategoryTextView: TextView = view.findViewById(R.id.category)
        val taskDeadlineTextView: TextView = view.findViewById(R.id.deadline)
        val deleteImageView: ImageView = view.findViewById(R.id.idIVDelete)
        val taskStatusCheckBox: CheckBox = view.findViewById(R.id.checkBox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(getLayoutForType(viewType), parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = allTasks[position]
        holder.taskTitleTextView.text = task.title
        holder.taskCategoryTextView.text = task.category
        holder.taskDeadlineTextView.text = task.deadline.toString()
        holder.taskStatusCheckBox.isChecked = task.done

        holder.deleteImageView.setOnClickListener {
            taskClickDeleteInterface.onDeleteIconClick(task)
        }

        holder.itemView.setOnClickListener {
            taskClickInterface.onTaskClick(task)
        }

        holder.taskStatusCheckBox.setOnCheckedChangeListener { _, isChecked ->
            taskStatusChangeInterface.onTaskStatusChange(task, isChecked)
        }
    }

    override fun getItemCount(): Int {
        return allTasks.size
    }

    override fun getItemViewType(position: Int): Int {
        val task = allTasks[position]
        return if (task.done) {
            R.layout.done_task_item
        } else {
            when (task.priority) {
                1 -> R.layout.task_item1
                2 -> R.layout.task_item2
                3 -> R.layout.task_item3
                else -> R.layout.base_task_item
            }
        }
    }

    fun updateList(newList: List<Task>) {
        allTasks.clear()
        allTasks.addAll(newList)
        notifyDataSetChanged()
    }

    private fun getLayoutForType(viewType: Int): Int {
        return when (viewType) {
            R.layout.task_item1 -> R.layout.task_item1
            R.layout.task_item2 -> R.layout.task_item2
            R.layout.task_item3 -> R.layout.task_item3
            R.layout.done_task_item -> R.layout.done_task_item
            else -> R.layout.base_task_item
        }
    }
}



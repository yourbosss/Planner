package com.example.planner

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class TaskViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: TaskRepository
    val allTasks: LiveData<List<Task>>

    init {
        val taskDao = AppDatabase.getDatabase(application).taskDao()
        repository = TaskRepository(taskDao)
        allTasks = repository.allTasks
    }

    fun insert(task: Task) = viewModelScope.launch {
        repository.insert(task)
    }

    fun update(task: Task) = viewModelScope.launch {
        repository.update(task)
    }

    fun delete(task: Task) = viewModelScope.launch {
        repository.delete(task)
    }

    fun getTasksById(): List<Task?>? {
        return repository.getTasksById()
    }

    fun getTasksWhereCategory(category: String): List<Task?>? {
        return repository.getTasksWhereCategory(category)
    }
    fun getTasksByDeadline1(): List<Task?>?{
        return repository.getTasksByDeadline1()
    }

    fun getTasksByDeadline0(): List<Task?>?{
        return repository.getTasksByDeadline0()
    }

    fun getTasksByPriority1(): List<Task?>?{
        return repository.getTasksByPriority1()
    }

    fun getTasksByPriority0(): List<Task?>?{
        return repository.getTasksByPriority0()
    }

    fun getTasksWhereStatus(status: Boolean): List<Task?>?{
        return repository.getTasksWhereStatus(status)
    }
}